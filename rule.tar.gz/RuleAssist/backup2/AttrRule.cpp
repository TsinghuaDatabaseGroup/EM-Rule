#include "AttrRule.h"



AttrRule::~AttrRule(void)
{
}
