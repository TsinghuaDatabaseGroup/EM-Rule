#include "UAttrRule.h"



UAttrRule::~UAttrRule(void)
{
}
