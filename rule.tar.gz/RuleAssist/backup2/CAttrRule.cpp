#include "CAttrRule.h"


CAttrRule::~CAttrRule(void)
{
}
