#pragma once
#include "Parser.h"
#include <fstream>


using namespace std;



void initRule(string ruleFilename, AttrRuleManager& arManager, TupleRuleManager& trManager);
void initTrain(string trainFilename, TrainData& trainData);